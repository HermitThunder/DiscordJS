const token = "TOKEN";

module.exports = token;
